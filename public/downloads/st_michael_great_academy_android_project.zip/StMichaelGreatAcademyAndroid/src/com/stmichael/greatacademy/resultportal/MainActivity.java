package com.stmichael.greatacademy.resultportal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    public static final String LIVE_URL = "https://ais-pre-yxhtecahnezg43ic3h5omk-29836764747.europe-west2.run.app/";
    public static final String DEV_URL = "https://ais-dev-yxhtecahnezg43ic3h5omk-29836764747.europe-west2.run.app/";

    // Desktop User Agent string (Forces complete desktop layout, exact desktop tables, sidebars, and colors)
    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final String MOBILE_UA = "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36";

    private static final String PREFS_NAME = "SMGA_PORTAL_PREFS";
    private static final String KEY_CURRENT_URL = "current_portal_url";
    private static final String KEY_IS_DESKTOP = "is_desktop_mode";

    private WebView webView;
    private ProgressBar progressBar;
    private TextView offlineBanner;
    private TextView portalSubtitle;
    private Button btnViewMode;
    private Button btnSwitchSite;
    private Button btnSync;
    private Button btnPrint;
    private SharedPreferences prefs;

    private boolean isDesktopMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        isDesktopMode = prefs.getBoolean(KEY_IS_DESKTOP, true);

        webView = (WebView) findViewById(R.id.webView);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        offlineBanner = (TextView) findViewById(R.id.offlineBanner);
        portalSubtitle = (TextView) findViewById(R.id.portalSubtitle);
        btnViewMode = (Button) findViewById(R.id.btnViewMode);
        btnSwitchSite = (Button) findViewById(R.id.btnSwitchSite);
        btnSync = (Button) findViewById(R.id.btnSync);
        btnPrint = (Button) findViewById(R.id.btnPrint);

        setupHighPerformanceWebView();
        setupControls();

        String targetUrl = getCurrentUrl();
        updateSwitchButtonLabel(targetUrl);
        updateViewModeButton();
        loadPortalUrl(targetUrl);
    }

    private String getCurrentUrl() {
        return prefs.getString(KEY_CURRENT_URL, LIVE_URL);
    }

    private void setCurrentUrl(String url) {
        prefs.edit().putString(KEY_CURRENT_URL, url).apply();
        updateSwitchButtonLabel(url);
    }

    private void updateSwitchButtonLabel(String url) {
        if (url.contains("ais-dev")) {
            btnSwitchSite.setText("DEV SITE");
            btnSwitchSite.setBackgroundColor(0xFF3B82F6); // Blue for dev
            btnSwitchSite.setTextColor(0xFFFFFFFF);
            portalSubtitle.setText("DEV / PREVIEW PORTAL • " + (isDesktopMode ? "DESKTOP MODE" : "MOBILE"));
        } else {
            btnSwitchSite.setText("LIVE SITE");
            btnSwitchSite.setBackgroundColor(0xFFF59E0B); // Amber Gold for live
            btnSwitchSite.setTextColor(0xFF040914);
            portalSubtitle.setText("OFFICIAL RESULT PORTAL • " + (isDesktopMode ? "DESKTOP MODE" : "MOBILE"));
        }
    }

    private void updateViewModeButton() {
        if (isDesktopMode) {
            btnViewMode.setText("DESKTOP: ON");
            btnViewMode.setBackgroundColor(0xFF10B981); // Emerald
            btnViewMode.setTextColor(0xFF040914);
        } else {
            btnViewMode.setText("MOBILE: ON");
            btnViewMode.setBackgroundColor(0xFF64748B); // Slate
            btnViewMode.setTextColor(0xFFFFFFFF);
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null) {
            NetworkInfo netInfo = cm.getActiveNetworkInfo();
            return netInfo != null && netInfo.isConnected();
        }
        return false;
    }

    private void setupHighPerformanceWebView() {
        // Enforce pure black background to prevent any white flashes
        webView.setBackgroundColor(0xFF060E1D);

        // Hardware-accelerated 60FPS fluid scrolling
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        }

        webView.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        webView.setOverScrollMode(View.OVER_SCROLL_ALWAYS);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);

        // Desktop Site viewport configuration
        applyViewportAndUserAgent();

        // Performance & caching
        settings.setRenderPriority(WebSettings.RenderPriority.HIGH);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAppCacheEnabled(true);
        settings.setEnableSmoothTransition(true);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                progressBar.setVisibility(View.VISIBLE);
                if (!isNetworkAvailable()) {
                    offlineBanner.setVisibility(View.VISIBLE);
                } else {
                    offlineBanner.setVisibility(View.GONE);
                }
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (!isNetworkAvailable()) {
                    offlineBanner.setVisibility(View.VISIBLE);
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                if (newProgress < 100) {
                    progressBar.setVisibility(View.VISIBLE);
                    progressBar.setProgress(newProgress);
                } else {
                    progressBar.setVisibility(View.GONE);
                }
            }
        });
    }

    private void applyViewportAndUserAgent() {
        WebSettings settings = webView.getSettings();
        if (isDesktopMode) {
            settings.setUserAgentString(DESKTOP_UA);
            settings.setUseWideViewPort(true);
            settings.setLoadWithOverviewMode(true);
            webView.setInitialScale(100);
        } else {
            settings.setUserAgentString(MOBILE_UA);
            settings.setUseWideViewPort(false);
            settings.setLoadWithOverviewMode(false);
            webView.setInitialScale(0);
        }
    }

    private void setupControls() {
        // Toggle Desktop View / Mobile View
        btnViewMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isDesktopMode = !isDesktopMode;
                prefs.edit().putBoolean(KEY_IS_DESKTOP, isDesktopMode).apply();
                applyViewportAndUserAgent();
                updateViewModeButton();
                updateSwitchButtonLabel(getCurrentUrl());
                webView.reload();
                Toast.makeText(MainActivity.this, isDesktopMode ? "Desktop Site Activated" : "Mobile Site Activated", Toast.LENGTH_SHORT).show();
            }
        });

        // Switch Site Dialog (Bold Black Theme)
        btnSwitchSite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDarkSiteSelectDialog();
            }
        });

        // Instant Sync & Refresh
        btnSync.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isNetworkAvailable()) {
                    offlineBanner.setVisibility(View.VISIBLE);
                    Toast.makeText(MainActivity.this, "Offline. Connect to internet to sync.", Toast.LENGTH_SHORT).show();
                } else {
                    offlineBanner.setVisibility(View.GONE);
                    Toast.makeText(MainActivity.this, "Syncing database & refreshing portal...", Toast.LENGTH_SHORT).show();
                    webView.clearCache(true);
                    webView.reload();
                }
            }
        });

        // Native Print / PDF
        btnPrint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                printCurrentPage();
            }
        });
    }

    // Bold Dark Theme Dialog for choosing environment
    private void showDarkSiteSelectDialog() {
        final String[] options = new String[]{
            "★ Live Published Portal (Official Live Site)",
            "⚡ Dev / Preview Site (Instant Testing & Recent Edits)",
            "✎ Enter Custom Portal Address..."
        };

        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        } else {
            builder = new AlertDialog.Builder(this, AlertDialog.THEME_HOLO_DARK);
        }

        builder.setTitle("Select Portal Environment");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    setCurrentUrl(LIVE_URL);
                    loadPortalUrl(LIVE_URL);
                    Toast.makeText(MainActivity.this, "Opened Live Published Portal", Toast.LENGTH_SHORT).show();
                } else if (which == 1) {
                    setCurrentUrl(DEV_URL);
                    loadPortalUrl(DEV_URL);
                    Toast.makeText(MainActivity.this, "Opened Dev / Preview Portal", Toast.LENGTH_SHORT).show();
                } else if (which == 2) {
                    showCustomUrlDialog();
                }
            }
        });
        builder.setNegativeButton("Close", null);
        builder.show();
    }

    private void showCustomUrlDialog() {
        final EditText input = new EditText(this);
        input.setHint("https://...");
        input.setText(getCurrentUrl());
        input.setTextColor(0xFFF8FAFC);
        input.setBackgroundColor(0xFF0F172A);

        AlertDialog.Builder builder;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder = new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK);
        } else {
            builder = new AlertDialog.Builder(this, AlertDialog.THEME_HOLO_DARK);
        }

        builder.setTitle("Custom School Portal URL");
        builder.setView(input);
        builder.setPositiveButton("Save & Connect", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newUrl = input.getText().toString().trim();
                if (!newUrl.isEmpty()) {
                    if (!newUrl.startsWith("http://") && !newUrl.startsWith("https://")) {
                        newUrl = "https://" + newUrl;
                    }
                    setCurrentUrl(newUrl);
                    loadPortalUrl(newUrl);
                }
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void loadPortalUrl(String url) {
        if (!isNetworkAvailable()) {
            offlineBanner.setVisibility(View.VISIBLE);
        } else {
            offlineBanner.setVisibility(View.GONE);
        }
        webView.loadUrl(url);
    }

    private void printCurrentPage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
            if (printManager != null) {
                PrintDocumentAdapter printAdapter = webView.createPrintDocumentAdapter();
                String jobName = "ST_MICHAEL_RESULT_" + System.currentTimeMillis();
                printManager.print(jobName, printAdapter, new PrintAttributes.Builder().build());
            } else {
                Toast.makeText(this, "Printing is not supported on this device", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
